package com.kyaublooddonateclub.kyaublooddonation;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONObject;

public class Sign_Up_Model {

    String name;
    String email;
    String mobile;
    String password;
    String profession;
    String upozilla;
    String department;
    String blood;
    String gender;



}
