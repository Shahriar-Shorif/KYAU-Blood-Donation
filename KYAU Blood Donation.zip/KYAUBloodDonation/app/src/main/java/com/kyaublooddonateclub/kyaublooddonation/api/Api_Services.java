package com.kyaublooddonateclub.kyaublooddonation.api;

public class Api_Services {

    public static String BASE_URL = "https://shorifulislam377.top/";
    public static String SIGN_UP_URL = BASE_URL+"/kyau-blood-donation-club/Sign_up.php";
    public static String LOGIN_URL = BASE_URL+"/kyau-blood-donation-club/login.php";
}
